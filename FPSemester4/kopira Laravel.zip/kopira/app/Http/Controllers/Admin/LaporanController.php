<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Simpanan;
use App\Models\Pinjaman;
use App\Models\Pembayaran;

class LaporanController extends Controller
{
    public function indexPage(Request $request)
    {
        $tanggalMulai = $request->input('tanggal_mulai') ?? now()->startOfMonth()->toDateString();
        $tanggalAkhir = $request->input('tanggal_akhir') ?? now()->endOfMonth()->toDateString();

        // Total ringkasan
        $totalSimpanan = Simpanan::whereBetween('tanggal', [$tanggalMulai, $tanggalAkhir])->sum('total_simpanan_wajib')
            + Simpanan::whereBetween('tanggal', [$tanggalMulai, $tanggalAkhir])->sum('total_simpanan_sukarela');

        $totalPinjaman = Pinjaman::whereBetween('tanggal_pinjam', [$tanggalMulai, $tanggalAkhir])->sum('nominal');
        $totalPembayaran = Pembayaran::whereBetween('tanggal', [$tanggalMulai, $tanggalAkhir])->sum('jumlah');
        $totalDenda = Pinjaman::whereBetween('tanggal_pinjam', [$tanggalMulai, $tanggalAkhir])->sum('denda');

        $saldoKas = $totalSimpanan + $totalPembayaran - $totalPinjaman;

        // Transaksi pinjaman
        $pinjaman = collect(Pinjaman::with('anggota')
            ->whereBetween('tanggal_pinjam', [$tanggalMulai, $tanggalAkhir])
            ->get()
            ->map(fn($p) => [
                'tanggal' => $p->tanggal_pinjam,
                'jenis' => 'Pinjaman',
                'nama' => $p->anggota->nama ?? '-',
                'keterangan' => 'Pencairan pinjaman',
                'jumlah' => $p->nominal
            ]));

        // Transaksi pembayaran
        $pembayaran = collect(Pembayaran::with('pinjaman.anggota')
            ->whereBetween('tanggal', [$tanggalMulai, $tanggalAkhir])
            ->get()
            ->map(fn($p) => [
                'tanggal' => $p->tanggal,
                'jenis' => 'Pembayaran',
                'nama' => $p->pinjaman->anggota->nama ?? '-',
                'keterangan' => 'Angsuran',
                'jumlah' => $p->jumlah
            ]));

        // Transaksi simpanan
        $simpanan = collect(Simpanan::with('anggota')
            ->whereBetween('tanggal', [$tanggalMulai, $tanggalAkhir])
            ->get()
            ->map(fn($s) => [
                'tanggal' => $s->tanggal,
                'jenis' => 'Simpanan ' . ucfirst($s->jenis),
                'nama' => $s->anggota->nama ?? '-',
                'keterangan' => 'Setoran simpanan',
                'jumlah' => $s->total_simpanan_wajib + $s->total_simpanan_sukarela
            ]));

        // Gabungkan semua transaksi
        $transaksi = $simpanan->merge($pinjaman)->merge($pembayaran)->sortBy('tanggal');

        return view('admin.pages.laporan.index', compact(
            'totalSimpanan',
            'totalPinjaman',
            'totalPembayaran',
            'totalDenda',
            'saldoKas',
            'transaksi',
            'tanggalMulai',
            'tanggalAkhir'
        ));
    }
}
