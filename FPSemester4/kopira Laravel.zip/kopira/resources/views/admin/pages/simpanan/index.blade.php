@extends('admin.layouts.base')
@section('title', 'Simpanan')
@section('content')
<h1 class="h3 mb-4 text-gray-800">Simpanan</h1>

<div class="row">
    <div class="container mt-5">
        <div class="mb-3 d-flex gap-3">
            <button type="button" class="btn btn-outline-success me-2">Cetak</button>

            {{-- Dropdown Jenis --}}
            <form method="GET" class="d-flex gap-2 mb-3">
                <select name="filter" class="form-select w-auto">
                    <option value="">-- Semua Jenis --</option>
                    <option value="wajib" {{ request('filter') == 'wajib' ? 'selected' : '' }}>Wajib</option>
                    <option value="sukarela" {{ request('filter') == 'sukarela' ? 'selected' : '' }}>Sukarela</option>
                </select>
                <button class="btn btn-primary">Tampilkan</button>
            </form>
        </div>

        <table class="table table-dark table-bordered">
            <thead>
                <tr class="fw-bold text-center">
                    <th>No</th>
                    <th>Tgl Daftar</th>
                    <th>Tanggal</th>
                    <th>Jenis</th>
                    <th>Anggota</th>
                    <th>Nominal</th>
                    <th>Total Saldo Wajib</th>
                    <th>Total Saldo Sukarela</th>
                    <th>Status Wajib</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($simpanan as $i => $s)
                <tr>
                    <td>{{ $i + 1 }}</td>
                    <td>{{ \Carbon\Carbon::parse($s->anggota->tanggal_daftar)->format('d M Y') ?? '-' }}</td>
                    <td>{{ \Carbon\Carbon::parse($s->tanggal)->format('d M Y') }}</td>
                    <td>{{ ucfirst($s->jenis) }}</td>
                    <td>{{ $s->anggota->nama ?? '-' }}</td>

                    {{-- Nominal --}}
                    <td>
                        Rp 
                        @if($s->jenis === 'wajib')
                            {{ number_format($s->total_simpanan_wajib, 0, ',', '.') }}
                        @elseif($s->jenis === 'sukarela')
                            {{ number_format($s->total_simpanan_sukarela, 0, ',', '.') }}
                        @else
                            0
                        @endif
                    </td>

                    {{-- Total Saldo Wajib --}}
                    <td>
                        Rp {{ number_format($s->anggota->simpanan->where('jenis', 'wajib')->sum('total_simpanan_wajib'), 0, ',', '.') }}
                    </td>

                    {{-- Total Saldo Sukarela --}}
                    <td>
                        Rp {{ number_format($s->anggota->simpanan->where('jenis', 'sukarela')->sum('total_simpanan_sukarela'), 0, ',', '.') }}
                    </td>

                    {{-- Status Wajib --}}
                    <td>
                        @php
                            $status = $statusPembayaran[$s->anggota->id ?? 0] ?? '-';
                            $badgeClass = match($status) {
                                'sudah membayar simpanan wajib' => 'success',
                                'belum membayar simpanan wajib bulan ini' => 'warning',
                                'telat membayar simpanan wajib' => 'danger',
                                'belum wajib membayar simpanan' => 'secondary',
                                default => 'dark',
                            };
                        @endphp
                        <span class="badge bg-{{ $badgeClass }}">{{ $status }}</span>
                    </td>



                    {{-- Aksi --}}
                    <td>
                        <a href="{{ route('simpanan.edit', $s->id) }}" class="btn btn-sm btn-warning">Edit</a>
                        <form action="{{ route('simpanan.hapus', $s->id) }}" method="POST" class="d-inline"
                            onsubmit="return confirm('Yakin ingin menghapus simpanan ini?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="9" class="text-center">Belum ada data simpanan</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
