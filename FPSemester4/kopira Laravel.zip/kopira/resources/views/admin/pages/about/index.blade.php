@extends('admin.layouts.base')
@section('title', 'About')
@section('content')
<h1 class="h3 mb-4 text-gray-800">About</h1>
@endsection