@extends('admin.layouts.base')
@section('title', 'Transaksi')
@section('content')
<h1 class="h3 mb-4 text-gray-800">Transaksi</h1>
@endsection