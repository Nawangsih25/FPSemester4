
<?php $__env->startSection('title', 'Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Daftar Pinjaman Belum Lunas</h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table class="table table-dark table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Anggota</th>
            <th>Nominal</th>
            <th>Sisa Tagihan</th>
            <th>Pembayaran</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($i + 1); ?></td>
            <td><?php echo e($p->anggota->nama ?? '-'); ?></td>
            <td>Rp <?php echo e(number_format($p->nominal, 0, ',', '.')); ?></td>
            <td>Rp <?php echo e(number_format($p->sisa_tagihan, 0, ',', '.')); ?></td>
            <td>
                <form action="<?php echo e(route('pembayaran.simpan')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="pinjaman_id" value="<?php echo e($p->id); ?>">
                    <input type="date" name="tanggal" class="form-control mb-1" required>
                    <input type="number" name="jumlah" class="form-control mb-1" placeholder="Jumlah bayar" required>
                    <select name="metode" class="form-select mb-1">
                        <option value="tunai">Tunai</option>
                        <option value="transfer">Transfer</option>
                    </select>
                    <button class="btn btn-success btn-sm">Bayar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5" class="text-center">Semua pinjaman sudah lunas.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/pembayaran/index.blade.php ENDPATH**/ ?>