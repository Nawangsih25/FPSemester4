
<?php $__env->startSection('title', 'Data Pinjaman'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Data Pinjaman</h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>


<div class="d-flex justify-content-between mb-3">
    <a href="<?php echo e(route('pinjaman.permintaan')); ?>" class="btn btn-outline-success">Permintaan Pinjaman</a>

    <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
            Filter Status
        </button>
        <ul class="dropdown-menu dropdown-menu-dark">
            <li><a class="dropdown-item" href="#">Lunas</a></li>
            <li><a class="dropdown-item" href="#">Belum Bayar</a></li>
            <li><a class="dropdown-item" href="#">Sudah Bayar</a></li>
        </ul>
    </div>
</div>

<table class="table table-dark table-bordered">
    <thead>
        <tr class="text-center">
            <th>No</th>
            <th>Anggota</th>
            <th>Pinjaman</th>
            <th>Lama</th>
            <th>Sisa Tagihan</th>
            <th>Denda</th>
            <th>Tanggal Pinjam</th>
            <th>Tanggal Konfirmasi</th>
            <th>Tagihan Hari Ini</th>
            <th>Keterangan</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($i + 1); ?></td>
            <td><?php echo e($p->anggota->nama ?? '-'); ?></td>
            <td>Rp <?php echo e(number_format($p->nominal, 0, ',', '.')); ?></td>
            <td><?php echo e($p->lama_angsuran ?? '-'); ?> bln</td>
            <td>Rp <?php echo e(number_format($p->sisa_tagihan ?? 0, 0, ',', '.')); ?></td>
            <td>Rp <?php echo e(number_format($p->denda ?? 0, 0, ',', '.')); ?></td>
            <td><?php echo e(\Carbon\Carbon::parse($p->tanggal_pinjam)->format('d M Y')); ?></td>
            <td><?php echo e($p->tanggal_respon ? \Carbon\Carbon::parse($p->tanggal_respon)->format('d M Y') : '-'); ?></td>
            <td>Rp <?php echo e(number_format($p->tagihan_hari_ini ?? 0, 0, ',', '.')); ?></td>
            <td>
                <?php if($p->status === 'ditolak'): ?>
                    <?php echo e($p->alasan_penolakan ?? '-'); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </td>

            <td class="text-center">
                <span class="badge 
                    <?php if($p->status == 'lunas'): ?> bg-success
                    <?php elseif($p->status == 'belum bayar'): ?> bg-danger
                    <?php elseif($p->status == 'sudah bayar'): ?> bg-warning
                    <?php elseif($p->status == 'pending'): ?> bg-info
                    <?php elseif($p->status == 'ditolak'): ?> bg-secondary
                    <?php else: ?> bg-dark
                    <?php endif; ?>">
                    <?php echo e(strtoupper($p->status)); ?>

                </span>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="11" class="text-center">Tidak ada data pinjaman.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/pinjaman/index.blade.php ENDPATH**/ ?>