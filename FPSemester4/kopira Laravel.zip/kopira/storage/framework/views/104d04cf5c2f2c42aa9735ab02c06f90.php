
<?php $__env->startSection('title', 'Tambah Kolektor'); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($err); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<h1 class="h3 mb-4 text-gray-800">Tambah Data Kolektor</h1>

<form action="<?php echo e(route('kolektor.simpan')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="row">
        
        <div class="col-md-8">

            
            <div class="mb-3">
                <label for="nama" class="form-label">Nama Kolektor</label>
                <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan nama kolektor">
            </div>

            
            <div class="mb-3">
                <label for="email" class="form-label">Email Kolektor</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="contoh@email.com">
            </div>

            
            <div class="mb-3">
                <label for="telepon" class="form-label">Nomor Telepon</label>
                <input type="text" class="form-control" id="telepon" name="telepon" placeholder="08xxxxxxxxxx">
            </div>

            
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <textarea class="form-control" id="alamat" name="alamat" rows="3" placeholder="Masukkan alamat lengkap"></textarea>
            </div>

            
            <div class="mb-3">
                <label for="nik" class="form-label">NIK</label>
                <input type="text" class="form-control" id="nik" name="nik" placeholder="Masukkan NIK (16 digit)">
            </div>

            
            <div class="mb-3">
                <label for="tanggal_daftar" class="form-label">Tanggal Daftar</label>
                <input type="date" class="form-control" id="tanggal_daftar" name="tanggal_daftar"
                       value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" readonly>
            </div>

            
            <div class="mb-3">
                <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                <select class="form-select" id="jenis_kelamin" name="jenis_kelamin">
                    <option value="">-- Pilih Jenis Kelamin --</option>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>

            
            <div class="mb-3">
                <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir">
            </div>

            
            <div class="mb-3">
                <label for="pendidikan" class="form-label">Pendidikan Terakhir</label>
                <select class="form-select" id="pendidikan" name="pendidikan">
                    <option value="">-- Pilih Pendidikan --</option>
                    <option value="SD">SD</option>
                    <option value="SMP">SMP</option>
                    <option value="SMA/SMK">SMA/SMK</option>
                    <option value="Diploma">Diploma</option>
                    <option value="Sarjana">Sarjana</option>
                    <option value="Magister">Magister</option>
                    <option value="Doktor">Doktor</option>
                </select>
            </div>

        </div>

        
        <div class="col-md-4">
            <div class="mb-3">
                <label for="foto" class="form-label">Foto</label>
                <input type="file" class="form-control" id="foto" name="foto" accept="image/*" onchange="previewFoto(event)">
                <small class="text-muted">Maksimal: 2048KB</small>
            </div>

            <div class="mb-3 text-center">
                <img id="preview-gambar" src="<?php echo e(asset('images/default.png')); ?>" class="img-fluid" alt="Preview Foto" style="max-height: 250px;">
            </div>
        </div>
    </div>

    
    <button type="submit" class="btn btn-primary">Simpan</button>
    <a href="#" class="btn btn-secondary">Batal</a>
</form>


<script>
    function previewFoto(event) {
        const reader = new FileReader();
        reader.onload = function () {
            document.getElementById('preview-gambar').src = reader.result;
        };
        reader.readAsDataURL(event.target.files[0]);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/kolektor/tambahkolektor.blade.php ENDPATH**/ ?>