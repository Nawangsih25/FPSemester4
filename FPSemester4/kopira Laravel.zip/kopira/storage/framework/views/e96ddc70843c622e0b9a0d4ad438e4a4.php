
<?php $__env->startSection('title', 'Review Permintaan Pinjaman'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Review Permintaan Pinjaman</h1>

<form action="<?php echo e(route('pinjaman.review', $pinjaman->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label class="form-label">ID Anggota</label>
        <input type="text" class="form-control" value="<?php echo e($pinjaman->anggota_id); ?>" readonly>
    </div>

    <div class="mb-3">
        <label class="form-label">Nominal</label>
        <input type="text" class="form-control" value="Rp <?php echo e(number_format($pinjaman->nominal, 0, ',', '.')); ?>" readonly>
    </div>

    <div class="mb-3">
        <label class="form-label">Tanggal Pinjam</label>
        <input type="text" class="form-control" value="<?php echo e(\Carbon\Carbon::parse($pinjaman->tanggal_pinjam)->format('d M Y')); ?>" readonly>
    </div>

    
    <div class="mb-3">
        <label class="form-label">Tindakan</label>
        <select name="tindakan" id="tindakan" class="form-select" required onchange="toggleForm()">
            <option value="">-- Pilih --</option>
            <option value="setujui">Setujui</option>
            <option value="tolak">Tolak</option>
        </select>
    </div>

    
    <div id="form-setujui" style="display: none">
        <div class="mb-3">
            <label class="form-label">Lama Angsuran (bulan)</label>
            <input type="number" name="lama_angsuran" class="form-control">
        </div>
    </div>

    
    <div id="form-tolak" style="display: none">
        <div class="mb-3">
            <label class="form-label">Alasan Penolakan</label>
            <textarea name="alasan_penolakan" class="form-control"></textarea>
        </div>
    </div>

    <button class="btn btn-primary">Kirim</button>
    <a href="<?php echo e(route('pinjaman.permintaan')); ?>" class="btn btn-secondary">Batal</a>
</form>

<script>
    function toggleForm() {
        const tindakan = document.getElementById('tindakan').value;
        document.getElementById('form-setujui').style.display = tindakan === 'setujui' ? 'block' : 'none';
        document.getElementById('form-tolak').style.display = tindakan === 'tolak' ? 'block' : 'none';
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/pinjaman/request.blade.php ENDPATH**/ ?>