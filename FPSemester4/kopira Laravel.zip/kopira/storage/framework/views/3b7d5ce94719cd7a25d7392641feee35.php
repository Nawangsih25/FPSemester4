
<?php $__env->startSection('title', 'Edit Anggota'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Edit Data Anggota</h1>

<form action="<?php echo e(route('anggota.update', $anggota->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">
        <div class="col-md-8">
            
            <div class="mb-3">
                <label for="no_rekening" class="form-label">Nomor Rekening</label>
                <input type="text" class="form-control" id="no_rekening" name="no_rekening" value="<?php echo e(old('no_rekening', $anggota->no_rekening)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e(old('nama', $anggota->nama)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="nik" class="form-label">NIK</label>
                <input type="text" class="form-control" id="nik" name="nik" value="<?php echo e(old('nik', $anggota->nik)); ?>" readonly>
            </div>

            
            <div class="mb-3">
                <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir', $anggota->tanggal_lahir)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                <select name="jenis_kelamin" id="jenis_kelamin" class="form-select">
                    <option value="Laki-laki" <?php echo e($anggota->jenis_kelamin === 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="Perempuan" <?php echo e($anggota->jenis_kelamin === 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
            </div>

            
            <div class="mb-3">
                <label for="telepon" class="form-label">Telepon</label>
                <input type="text" class="form-control" id="telepon" name="telepon" value="<?php echo e(old('telepon', $anggota->telepon)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <textarea name="alamat" id="alamat" class="form-control" rows="3"><?php echo e(old('alamat', $anggota->alamat)); ?></textarea>
            </div>

            
            <div class="mb-3">
                <label for="pekerjaan" class="form-label">Pekerjaan</label>
                <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" value="<?php echo e(old('pekerjaan', $anggota->pekerjaan)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="pendidikan" class="form-label">Pendidikan</label>
                <select name="pendidikan" id="pendidikan" class="form-select">
                    <?php $__currentLoopData = ['SD','SMP','SMA/SMK','Diploma','Sarjana','Magister','Doktor']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($edu); ?>" <?php echo e($anggota->pendidikan === $edu ? 'selected' : ''); ?>><?php echo e($edu); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="mb-3">
                <label for="tanggal_daftar" class="form-label">Tanggal Daftar</label>
                <input type="date" class="form-control" id="tanggal_daftar" name="tanggal_daftar" value="<?php echo e(old('tanggal_daftar', $anggota->tanggal_daftar)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="deposito_awal" class="form-label">Deposito Awal (Rp)</label>
                <input type="number" class="form-control" id="deposito_awal" name="deposito_awal" value="<?php echo e(old('deposito_awal', $anggota->deposito_awal)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select name="status" id="status" class="form-select">
                    <option value="aktif" <?php echo e($anggota->status === 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                    <option value="tidak aktif" <?php echo e($anggota->status === 'tidak aktif' ? 'selected' : ''); ?>>Tidak Aktif</option>
                </select>
            </div>
        </div>

        
        <div class="col-md-4">
            <div class="mb-3">
                <label for="foto" class="form-label">Foto</label>
                <input type="file" class="form-control" name="foto" accept="image/*">
                <?php if($anggota->foto): ?>
                    <img src="<?php echo e(asset('storage/' . $anggota->foto)); ?>" class="img-fluid mt-2" width="150" alt="Foto">
                <?php endif; ?>
            </div>
        </div>
    </div>

    <button class="btn btn-primary">Simpan Perubahan</button>
    <a href="<?php echo e(route('anggota.index')); ?>" class="btn btn-secondary">Batal</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/anggota/edit.blade.php ENDPATH**/ ?>