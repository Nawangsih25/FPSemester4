
<?php $__env->startSection('title', 'Uji Coba Simpanan'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Uji Coba Input Simpanan</h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<form action="<?php echo e(route('test.simpanan')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label class="form-label">Anggota</label>
        <select name="anggota_id" class="form-select" required>
            <option value="">-- Pilih Anggota --</option>
            <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($a->id); ?>"><?php echo e($a->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Jenis Simpanan</label>
        <select name="jenis" class="form-select" required>
            <option value="">-- Pilih Jenis --</option>
            <option value="wajib">Wajib</option>
            <option value="sukarela">Sukarela</option>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Tanggal Simpanan</label>
        <input type="date" name="tanggal" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Nominal Simpanan</label>
        <input type="number" name="nominal" class="form-control" min="1000" required>
    </div>

    <button type="submit" class="btn btn-primary">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/test/simpanan.blade.php ENDPATH**/ ?>