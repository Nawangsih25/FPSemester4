
<?php $__env->startSection('title', 'Edit Kolektor'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Edit Data Kolektor</h1>

<form action="<?php echo e(route('kolektor.update', $kolektor->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">
        
        <div class="col-md-8">
            
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" name="nama" id="nama" class="form-control"
                       value="<?php echo e(old('nama', $kolektor->nama)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" class="form-control"
                       value="<?php echo e(old('email', $kolektor->email)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="telepon" class="form-label">Telepon</label>
                <input type="text" name="telepon" id="telepon" class="form-control"
                       value="<?php echo e(old('telepon', $kolektor->telepon)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <textarea name="alamat" id="alamat" class="form-control"><?php echo e(old('alamat', $kolektor->alamat)); ?></textarea>
            </div>

            
            <div class="mb-3">
                <label for="nik" class="form-label">NIK</label>
                <input type="text" name="nik" id="nik" class="form-control"
                       value="<?php echo e($kolektor->nik); ?>" readonly>
            </div>

            
            <div class="mb-3">
                <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control"
                       value="<?php echo e(old('tanggal_lahir', $kolektor->tanggal_lahir)); ?>">
            </div>

            
            <div class="mb-3">
                <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                <select name="jenis_kelamin" id="jenis_kelamin" class="form-select">
                    <option value="Laki-laki" <?php echo e(old('jenis_kelamin', $kolektor->jenis_kelamin) == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="Perempuan" <?php echo e(old('jenis_kelamin', $kolektor->jenis_kelamin) == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
            </div>

            
            <div class="mb-3">
                <label for="pendidikan" class="form-label">Pendidikan</label>
                <select name="pendidikan" id="pendidikan" class="form-select">
                    <?php $__currentLoopData = ['SD','SMP','SMA/SMK','Diploma','Sarjana','Magister','Doktor']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level); ?>" <?php echo e(old('pendidikan', $kolektor->pendidikan) == $level ? 'selected' : ''); ?>>
                            <?php echo e($level); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="mb-3">
                <label for="tanggal_daftar" class="form-label">Tanggal Daftar</label>
                <input type="date" name="tanggal_daftar" id="tanggal_daftar" class="form-control"
                       value="<?php echo e(old('tanggal_daftar', $kolektor->tanggal_daftar)); ?>">
            </div>
        </div>

        
        <div class="col-md-4">
            
            <div class="mb-3">
                <label for="foto" class="form-label">Foto</label>
                <input type="file" name="foto" class="form-control" accept="image/*">

                <?php if($kolektor->foto): ?>
                    <div class="mt-3">
                        <img src="<?php echo e(asset('storage/' . $kolektor->foto)); ?>" class="img-thumbnail" width="150">
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <button class="btn btn-primary">Simpan Perubahan</button>
    <a href="<?php echo e(route('kolektor.index')); ?>" class="btn btn-secondary">Kembali</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/kolektor/edit.blade.php ENDPATH**/ ?>