
<?php $__env->startSection('title', 'Detail Kolektor'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Detail Data Kolektor</h1>

<div class="card shadow mb-4">
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th>Nama</th>
                <td><?php echo e($kolektor->nama); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo e($kolektor->email); ?></td>
            </tr>
            <tr>
                <th>Telepon</th>
                <td><?php echo e($kolektor->telepon); ?></td>
            </tr>
            <tr>
                <th>Alamat</th>
                <td><?php echo e($kolektor->alamat); ?></td>
            </tr>
            <tr>
                <th>NIK</th>
                <td><?php echo e($kolektor->nik); ?></td>
            </tr>
            <tr>
                <th>Tanggal Lahir</th>
                <td><?php echo e(\Carbon\Carbon::parse($kolektor->tanggal_lahir)->format('d-m-Y')); ?></td>
            </tr>
            <tr>
                <th>Jenis Kelamin</th>
                <td><?php echo e($kolektor->jenis_kelamin); ?></td>
            </tr>
            <tr>
                <th>Pendidikan</th>
                <td><?php echo e($kolektor->pendidikan ?? '-'); ?></td>
            </tr>
            <tr>
                <th>Tanggal Daftar</th>
                <td><?php echo e(\Carbon\Carbon::parse($kolektor->tanggal_daftar)->format('d-m-Y')); ?></td>
            </tr>
            <tr>
                <th>Foto</th>
                <td>
                    <?php if($kolektor->foto): ?>
                        <img src="<?php echo e(asset('storage/' . $kolektor->foto)); ?>" alt="Foto Kolektor" class="img-thumbnail" width="150">
                    <?php else: ?>
                        <span class="text-muted">Tidak ada foto</span>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <a href="<?php echo e(route('kolektor.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/kolektor/detail.blade.php ENDPATH**/ ?>