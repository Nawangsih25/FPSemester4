
<?php $__env->startSection('title', 'Laporan Keuangan Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Laporan Keuangan Transaksi</h1>

<div class="card shadow mb-4">
    <div class="card-body">

        
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="alert alert-primary">
                    <strong>Total Simpanan:</strong><br> Rp <?php echo e(number_format($totalSimpanan, 0, ',', '.')); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="alert alert-success">
                    <strong>Total Pinjaman:</strong><br> Rp <?php echo e(number_format($totalPinjaman, 0, ',', '.')); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="alert alert-info">
                    <strong>Total Pembayaran:</strong><br> Rp <?php echo e(number_format($totalPembayaran, 0, ',', '.')); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="alert alert-warning">
                    <strong>Total Denda:</strong><br> Rp <?php echo e(number_format($totalDenda, 0, ',', '.')); ?>

                </div>
            </div>
        </div>

        
        <div class="mb-4">
            <div class="alert alert-dark">
                <strong>Saldo Kas Koperasi:</strong> Rp <?php echo e(number_format($saldoKas, 0, ',', '.')); ?>

            </div>
        </div>

        
        <form class="row g-3 align-items-end mb-3" method="GET" action="<?php echo e(route('laporan.index')); ?>">
            <div class="col-md-4">
                <label for="tanggal_mulai" class="form-label">Tanggal Mulai</label>
                <input type="date" id="tanggal_mulai" name="tanggal_mulai" class="form-control" value="<?php echo e($tanggalMulai); ?>">
            </div>
            <div class="col-md-4">
                <label for="tanggal_akhir" class="form-label">Tanggal Akhir</label>
                <input type="date" id="tanggal_akhir" name="tanggal_akhir" class="form-control" value="<?php echo e($tanggalAkhir); ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary w-100">Tampilkan Laporan</button>
            </div>
        </form>

        
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Tanggal</th>
                        <th>Jenis Transaksi</th>
                        <th>Nama Anggota</th>
                        <th>Keterangan</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(\Carbon\Carbon::parse($t['tanggal'])->format('d M Y')); ?></td>
                        <td><?php echo e($t['jenis']); ?></td>
                        <td><?php echo e($t['nama']); ?></td>
                        <td><?php echo e($t['keterangan']); ?></td>
                        <td>Rp <?php echo e(number_format($t['jumlah'], 0, ',', '.')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">Tidak ada transaksi pada periode ini.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="mt-3 d-flex justify-content-end gap-2">
            <button type="button" class="btn btn-danger">Export PDF</button>
            <button type="button" class="btn btn-success">Export Excel</button>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/laporan/index.blade.php ENDPATH**/ ?>