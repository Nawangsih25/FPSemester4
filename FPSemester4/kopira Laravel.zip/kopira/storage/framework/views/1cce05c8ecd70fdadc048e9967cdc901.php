
<?php $__env->startSection('title', 'Edit Simpanan'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Edit Simpanan</h1>

<form action="<?php echo e(route('simpanan.update', $simpanan->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label class="form-label">Nama Anggota</label>
        <input type="text" class="form-control" value="<?php echo e($simpanan->anggota->nama); ?>" readonly>
    </div>

    <div class="mb-3">
        <label class="form-label">Jenis Simpanan</label>
        <select name="jenis" class="form-select" required>
            <option value="wajib" <?php echo e($simpanan->jenis == 'wajib' ? 'selected' : ''); ?>>Wajib</option>
            <option value="sukarela" <?php echo e($simpanan->jenis == 'sukarela' ? 'selected' : ''); ?>>Sukarela</option>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Tanggal</label>
        <input type="date" name="tanggal" class="form-control" value="<?php echo e(\Carbon\Carbon::parse($simpanan->tanggal)->format('Y-m-d')); ?>">
    </div>

    <div class="mb-3">
        <label class="form-label">Nominal</label>
        <input type="number" name="nominal" class="form-control"
               value="<?php echo e($simpanan->jenis == 'wajib' ? $simpanan->total_simpanan_wajib : $simpanan->total_simpanan_sukarela); ?>">
    </div>

    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
    <a href="<?php echo e(route('simpanan.index')); ?>" class="btn btn-secondary">Batal</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/simpanan/edit.blade.php ENDPATH**/ ?>