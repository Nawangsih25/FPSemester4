
<?php $__env->startSection('title', 'Tambah Anggota'); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<h1 class="h3 mb-4 text-gray-800">Tambah Data Anggota</h1>

<form action="<?php echo e(route('anggota.simpan')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="row">
        
        <div class="col-md-8">
            
            <div class="mb-3">
                <label for="no_rekening" class="form-label">Nomor Rekening</label>
                <input type="text" class="form-control" id="no_rekening" name="no_rekening" placeholder="Masukkan nomor rekening">
            </div>

            
            <div class="mb-3">
                <label for="nama" class="form-label">Nama Anggota</label>
                <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan nama anggota">
            </div>

            
            <div class="mb-3">
                <label for="nik" class="form-label">NIK</label>
                <input type="text" class="form-control" id="nik" name="nik" placeholder="Masukkan NIK">
            </div>

            
            <div class="mb-3">
                <label for="bergabung" class="form-label">Tanggal Daftar</label>
                <input type="date" class="form-control" id="bergabung" name="bergabung"
                       value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" readonly>
            </div>

            
            <div class="mb-3">
                <label for="deposito_awal" class="form-label">Deposito Awal (Rp)</label>
                <input type="number" class="form-control" id="deposito_awal" name="deposito_awal" placeholder="Contoh: 1000000">
            </div>

            
            <div class="mb-3">
                <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                <select class="form-select" id="jenis_kelamin" name="jenis_kelamin">
                    <option value="">-- Pilih Jenis Kelamin --</option>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>

            
            <div class="mb-3">
                <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir">
            </div>

            
            <div class="mb-3">
                <label for="telepon" class="form-label">Nomor Telepon</label>
                <input type="text" class="form-control" id="telepon" name="telepon" placeholder="08xxxxxxxxxx">
            </div>

            
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <textarea class="form-control" id="alamat" name="alamat" rows="3" placeholder="Masukkan alamat lengkap"></textarea>
            </div>

            
            <div class="mb-3">
                <label for="pekerjaan" class="form-label">Pekerjaan</label>
                <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" placeholder="Masukkan pekerjaan">
            </div>

            
            <div class="mb-3">
                <label for="pendidikan" class="form-label">Pendidikan Terakhir</label>
                <select class="form-select" id="pendidikan" name="pendidikan">
                    <option value="">-- Pilih Pendidikan --</option>
                    <option value="SD">SD</option>
                    <option value="SMP">SMP</option>
                    <option value="SMA/SMK">SMA/SMK</option>
                    <option value="Diploma">Diploma</option>
                    <option value="Sarjana">Sarjana</option>
                    <option value="Magister">Magister</option>
                    <option value="Doktor">Doktor</option>
                </select>
            </div>

            
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <input type="text" class="form-control" id="status" name="status" value="aktif" readonly>
                <small class="text-muted">Akun akan otomatis menjadi "Tidak Aktif" jika tidak digunakan selama 3 bulan.</small>
            </div>
        </div>

        
        <div class="col-md-4">
            
            <div class="mb-3">
                <label for="foto" class="form-label">Foto</label>
                <input type="file" class="form-control" id="foto" name="foto" accept="image/*" onchange="previewFoto(event)">
                <small class="text-muted">Maksimal: 2048KB</small>
            </div>

            
            <div class="mb-3 text-center">
                <img id="preview-gambar" src="<?php echo e(asset('images/default.png')); ?>" class="img-fluid" alt="Preview Foto" style="max-height: 250px;">
            </div>
        </div>
    </div>

    
    <button type="submit" class="btn btn-primary">Simpan</button>
    <a href="#" class="btn btn-secondary">Batal</a>
</form>


<script>
    function previewFoto(event) {
        const reader = new FileReader();
        reader.onload = function () {
            const output = document.getElementById('preview-gambar');
            output.src = reader.result;
        };
        reader.readAsDataURL(event.target.files[0]);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/anggota/tambahanggota.blade.php ENDPATH**/ ?>