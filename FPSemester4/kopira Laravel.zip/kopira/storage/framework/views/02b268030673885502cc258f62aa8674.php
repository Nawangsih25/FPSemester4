
<?php $__env->startSection('title', 'Relasi Kolektor & Anggota'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Relasi Kolektor & Anggota</h1>


<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>


<div class="card shadow mb-4">
    <div class="card-header bg-primary text-white">
        Tambah Relasi Kolektor ke Anggota
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('relasi.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="kolektor_id" class="form-label">Pilih Kolektor</label>
                    <select name="kolektor_id" id="kolektor_id" class="form-select" required>
                        <option value="">-- Pilih Kolektor --</option>
                        <?php $__currentLoopData = $kolektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="anggota_id" class="form-label">Pilih Anggota</label>
                    <select name="anggota_id" id="anggota_id" class="form-select" required>
                        <option value="">-- Pilih Anggota --</option>
                        <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($a->id); ?>"><?php echo e($a->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-success">Tambahkan Relasi</button>
        </form>
    </div>
</div>


<div class="card shadow">
    <div class="card-header bg-dark text-white">
        Daftar Relasi Kolektor - Anggota
    </div>
    <div class="card-body table-responsive">
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Nama Kolektor</th>
                    <th>Nama Anggota</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $relasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($r->kolektor->nama ?? '-'); ?></td>
                    <td><?php echo e($r->anggota->nama ?? '-'); ?></td>
                    <td>
                        <form action="<?php echo e(route('relasi.destroy', $r->id)); ?>" method="POST" onsubmit="return confirm('Yakin hapus relasi ini?')" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">Belum ada relasi</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/relasianggotakolektor/index.blade.php ENDPATH**/ ?>