
<?php $__env->startSection('title', 'Permintaan Pinjaman'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Permintaan Pinjaman</h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="table-responsive">
    <table class="table table-bordered table-dark">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Anggota</th>
                <th>Nominal</th>
                <th>Tanggal Pinjam</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e($p->anggota->nama ?? '-'); ?></td>
                <td>Rp <?php echo e(number_format($p->nominal, 0, ',', '.')); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($p->tanggal_pinjam)->format('d M Y')); ?></td>
                <td>
                    <a href="<?php echo e(route('pinjaman.review.form', $p->id)); ?>" class="btn btn-primary btn-sm">
                        Review
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center">Belum ada permintaan pinjaman.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/pinjaman/permintaan.blade.php ENDPATH**/ ?>