
<?php $__env->startSection('title', 'Simpanan'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Simpanan</h1>

<div class="row">
    <div class="container mt-5">
        <div class="mb-3 d-flex gap-3">
            <button type="button" class="btn btn-outline-success me-2">Cetak</button>

            
            <form method="GET" class="d-flex gap-2 mb-3">
                <select name="filter" class="form-select w-auto">
                    <option value="">-- Semua Jenis --</option>
                    <option value="wajib" <?php echo e(request('filter') == 'wajib' ? 'selected' : ''); ?>>Wajib</option>
                    <option value="sukarela" <?php echo e(request('filter') == 'sukarela' ? 'selected' : ''); ?>>Sukarela</option>
                </select>
                <button class="btn btn-primary">Tampilkan</button>
            </form>
        </div>

        <table class="table table-dark table-bordered">
            <thead>
                <tr class="fw-bold text-center">
                    <th>No</th>
                    <th>Tgl Daftar</th>
                    <th>Tanggal</th>
                    <th>Jenis</th>
                    <th>Anggota</th>
                    <th>Nominal</th>
                    <th>Total Saldo Wajib</th>
                    <th>Total Saldo Sukarela</th>
                    <th>Status Wajib</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $simpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($s->anggota->tanggal_daftar)->format('d M Y') ?? '-'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($s->tanggal)->format('d M Y')); ?></td>
                    <td><?php echo e(ucfirst($s->jenis)); ?></td>
                    <td><?php echo e($s->anggota->nama ?? '-'); ?></td>

                    
                    <td>
                        Rp 
                        <?php if($s->jenis === 'wajib'): ?>
                            <?php echo e(number_format($s->total_simpanan_wajib, 0, ',', '.')); ?>

                        <?php elseif($s->jenis === 'sukarela'): ?>
                            <?php echo e(number_format($s->total_simpanan_sukarela, 0, ',', '.')); ?>

                        <?php else: ?>
                            0
                        <?php endif; ?>
                    </td>

                    
                    <td>
                        Rp <?php echo e(number_format($s->anggota->simpanan->where('jenis', 'wajib')->sum('total_simpanan_wajib'), 0, ',', '.')); ?>

                    </td>

                    
                    <td>
                        Rp <?php echo e(number_format($s->anggota->simpanan->where('jenis', 'sukarela')->sum('total_simpanan_sukarela'), 0, ',', '.')); ?>

                    </td>

                    
                    <td>
                        <?php echo e($statusPembayaran[$s->anggota->id ?? 0] ?? '-'); ?>

                    </td>


                    
                    <td>
                        <a href="<?php echo e(route('simpanan.edit', $s->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('simpanan.hapus', $s->id)); ?>" method="POST" class="d-inline"
                            onsubmit="return confirm('Yakin ingin menghapus simpanan ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center">Belum ada data simpanan</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/simpanan/index.blade.php ENDPATH**/ ?>