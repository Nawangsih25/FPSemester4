
<?php $__env->startSection('title', 'Anggota'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Anggota</h1>


<a href="<?php echo e(route('anggota.tambah')); ?>" class="btn btn-success mb-3">+ Tambah Anggota</a>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table class="table table-dark table-bordered">
    <thead>
        <tr class="fw-bold text-center">
            <th>No</th>
            <th>Bergabung</th>
            <th>No. Rekening</th>
            <th>Nama</th>
            <th>NIK</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="text-center align-middle">
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_daftar)->format('d M Y')); ?></td>
                <td><?php echo e($item->no_rekening); ?></td>
                <td><?php echo e($item->nama); ?></td>
                <td><?php echo e($item->nik); ?></td>
                <td>
                    <span class="badge bg-<?php echo e($item->status == 'aktif' ? 'success' : 'secondary'); ?>">
                        <?php echo e(ucfirst($item->status)); ?>

                    </span>
                </td>
                <td>
                    <a href="<?php echo e(route('anggota.detail', $item->id)); ?>" class="btn btn-info btn-sm">Detail</a>
                    <a href="<?php echo e(route('anggota.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('anggota.hapus', $item->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus data ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" class="text-center">Belum ada data anggota</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/Anggota/index.blade.php ENDPATH**/ ?>