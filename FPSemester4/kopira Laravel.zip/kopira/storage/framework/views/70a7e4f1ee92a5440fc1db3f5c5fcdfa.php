
<?php $__env->startSection('title', 'Kolektor'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Data Kolektor</h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<a href="<?php echo e(route('kolektor.tambah')); ?>" class="btn btn-info mb-3">+ Tambah Kolektor</a>

<table class="table table-bordered table-hover bg-white border-success table-striped">
    <thead>
        <tr class="fw-bold text-center bg-success text-light">
            <th>No</th>
            <th>Nama</th>
            <th>Email</th>
            <th>NIK</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $kolektor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td class="text-center"><?php echo e($i + 1); ?></td>
            <td><?php echo e($kolektor->nama); ?></td>
            <td><?php echo e($kolektor->email); ?></td>
            <td><?php echo e($kolektor->nik); ?></td>
            <td class="text-center">
                <span class="badge bg-success">Aktif</span> 
            </td>
            <td class="text-center">
                <a href="<?php echo e(route('kolektor.detail', $kolektor->id)); ?>" class="btn btn-sm btn-primary">Detail</a>
                <a href="<?php echo e(route('kolektor.edit', $kolektor->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="<?php echo e(route('kolektor.naungi', $kolektor->id)); ?>" class="btn btn-sm btn-info">Naungi</a>
                <form action="<?php echo e(route('kolektor.hapus', $kolektor->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-danger" onclick="return confirm('Hapus data ini?')">Hapus</button>
                </form>
            </td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="text-center">Belum ada data kolektor.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/kolektor/index.blade.php ENDPATH**/ ?>