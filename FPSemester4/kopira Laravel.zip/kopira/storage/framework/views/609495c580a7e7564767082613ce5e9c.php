
<?php $__env->startSection('title', 'Kelola Naungan Kolektor'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Kelola Naungan untuk Kolektor: <strong><?php echo e($kolektor->nama); ?></strong></h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>


<div class="card mb-4">
    <div class="card-header">Tambah Anggota untuk Kolektor Ini</div>
    <div class="card-body">
        <form action="<?php echo e(route('relasi.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="kolektor_id" value="<?php echo e($kolektor->id); ?>">
            <div class="row">
                <div class="col-md-8">
                    <select name="anggota_id" class="form-select" required>
                        <option value="">-- Pilih Anggota --</option>
                        <?php $__currentLoopData = $semuaAnggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($anggota->id); ?>"><?php echo e($anggota->nama); ?> (<?php echo e($anggota->nik); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button class="btn btn-primary w-100">Tambahkan</button>
                </div>
            </div>
        </form>
    </div>
</div>


<div class="card">
    <div class="card-header">Anggota yang Dinaungi</div>
    <div class="card-body">
        <?php if($anggotaNaungan->isEmpty()): ?>
            <p>Belum ada anggota yang dinaungi.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered table-dark align-middle">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Foto</th>
                            <th>Nama</th>
                            <th>Telepon</th>
                            <th>Alamat</th>
                            <th>Status Pinjaman</th>
                            <th>Tagihan Hari Ini</th>
                            <th>Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $anggotaNaungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $pinjamanAktif = $a->pinjaman()
                                ->whereNotIn('status', ['lunas', 'ditolak'])
                                ->latest('tanggal_pinjam')
                                ->first();
                        ?>
                        <tr>
                            <td><?php echo e($i + 1); ?></td>
                            <td>
                                <?php if($a->foto): ?>
                                    <img src="<?php echo e(asset('storage/' . $a->foto)); ?>" alt="Foto" width="50" height="50" class="rounded-circle">
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($a->nama); ?></td>
                            <td><?php echo e($a->telepon); ?></td>
                            <td><?php echo e($a->alamat); ?></td>
                            <td><?php echo e($pinjamanAktif->status ?? '-'); ?></td>
                            <td>Rp <?php echo e(number_format($pinjamanAktif->tagihan_hari_ini ?? 0, 0, ',', '.')); ?></td>
                            <td>
                                <?php if($pinjamanAktif): ?>
                                <form action="<?php echo e(route('pembayaran.simpan')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="pinjaman_id" value="<?php echo e($pinjamanAktif->id); ?>">
                                    <input type="hidden" name="tanggal" value="<?php echo e(date('Y-m-d')); ?>">
                                    <input type="hidden" name="jumlah" value="<?php echo e($pinjamanAktif->tagihan_hari_ini); ?>">
                                    <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Bayar tagihan hari ini untuk <?php echo e($a->nama); ?>?')">Bayar</button>
                                </form>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <form action="<?php echo e(route('relasi.destroy', $a->pivot->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus relasi ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kopira\resources\views/admin/pages/relasianggotakolektor/kelola.blade.php ENDPATH**/ ?>